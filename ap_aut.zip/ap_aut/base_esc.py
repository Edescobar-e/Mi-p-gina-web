
import pandas as pd
import numpy as np

# ==========================================
# 1. CARGAR EL DATASET
# ==========================================

ruta = "StudentPerformanceFactors.csv"

df = pd.read_csv(ruta)

print("\n========== DATOS ORIGINALES ==========")

print("Dimensiones:", df.shape)

print("\nPrimeros 5 registros:")
print(df.head())

# ==========================================
# 2. INFORMACION GENERAL
# ==========================================

print("\n========== INFORMACION GENERAL ==========")

df.info()

print("\nColumnas del dataset:")
print(df.columns.tolist())

# ==========================================
# 3. IDENTIFICAR VALORES FALTANTES
# ==========================================

print("\n========== VALORES FALTANTES ==========")

print(df.isnull().sum())

print("\nTotal de valores faltantes:")
print(df.isnull().sum().sum())

# ==========================================
# 4. IDENTIFICAR DUPLICADOS
# ==========================================

print("\n========== REGISTROS DUPLICADOS ==========")

print("Duplicados encontrados:", df.duplicated().sum())

# ==========================================
# 5. ELIMINAR DUPLICADOS
# ==========================================

df = df.drop_duplicates()

print("\nDuplicados después de la limpieza:")
print(df.duplicated().sum())

# ==========================================
# 6. TRATAR VALORES FALTANTES
# ==========================================

print("\n========== TRATAMIENTO DE VALORES FALTANTES ==========")

for columna in df.columns:

    if df[columna].isnull().sum() > 0:

        if pd.api.types.is_numeric_dtype(df[columna]):

            mediana = df[columna].median()

            df[columna] = df[columna].fillna(mediana)

            print(f"{columna}: valores reemplazados con la mediana ({mediana})")

        else:

            moda = df[columna].mode()

            if not moda.empty:

                df[columna] = df[columna].fillna(moda[0])

                print(f"{columna}: valores reemplazados con la moda ({moda[0]})")

# ==========================================
# 7. DETECTAR VALORES ATIPICOS
# ==========================================

print("\n========== DETECCION DE VALORES ATIPICOS ==========")

columnas_numericas = df.select_dtypes(
    include=np.number
).columns

for columna in columnas_numericas:

    Q1 = df[columna].quantile(0.25)
    Q3 = df[columna].quantile(0.75)

    IQR = Q3 - Q1

    limite_inferior = Q1 - 1.5 * IQR
    limite_superior = Q3 + 1.5 * IQR

    cantidad = (
        (df[columna] < limite_inferior) |
        (df[columna] > limite_superior)
    ).sum()

    print(f"{columna}: {cantidad} posibles valores atipicos")

# ==========================================
# 8. VERIFICAR RESULTADOS DE LA LIMPIEZA
# ==========================================

print("\n========== RESULTADOS FINALES ==========")

print("Dimensiones originales:", df.shape)

print("Valores faltantes restantes:", df.isnull().sum().sum())

print("Duplicados restantes:", df.duplicated().sum())

# ==========================================
# 9. GUARDAR DATASET LIMPIO
# ==========================================

nombre_salida = "StudentPerformanceFactors_Limpio.csv"

df.to_csv(nombre_salida, index=False)

print("\n========== PROCESO FINALIZADO ==========")

print("Dataset limpio guardado como:", nombre_salida)

print("\nPrimeros registros del dataset limpio:")
print(df.head())
